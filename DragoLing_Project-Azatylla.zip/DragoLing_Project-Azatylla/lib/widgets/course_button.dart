import 'package:flutter/material.dart';

class CourseButton extends StatefulWidget {
  final String text;
  final GestureTapCallback? onTap;
  const CourseButton({super.key, this.text = "", this.onTap});

  @override
  State<CourseButton> createState() => _CourseButtonState();
}

class _CourseButtonState extends State<CourseButton> {
  double _opacity = 1.0;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (details) {
        _opacity = 0.4;
        setState(() {});
      },
      onTapUp: (details) {
        _opacity = 1.0;
        setState(() {});
      },
      onTap: widget.onTap,
      child: AnimatedOpacity(
        opacity: _opacity,
        duration: Duration(milliseconds: 150),
        curve: Curves.easeOut,
        child: Container(
          decoration: BoxDecoration(
            shape: BoxShape.rectangle,
            border: Border.all(
              color: const Color(0xffDF9629),
              width: 1.0,
            ),
            borderRadius: BorderRadius.circular(10),
            color: const Color(0xff543D3D).withOpacity(0.15),
          ),
          alignment: Alignment.center,
          width: 60,
          height: 60,
          margin: const EdgeInsets.all(10.0),
          child: Text(
            widget.text,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ),
    );
  }
}
