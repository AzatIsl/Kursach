import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class CustomTextFieldDefault extends StatefulWidget {
  final String hintText;
  final Function(String text)? onChange;

  const CustomTextFieldDefault({super.key, this.hintText = "", this.onChange});

  @override
  State<CustomTextFieldDefault> createState() => _CustomTextFieldDefaultState();
}

class _CustomTextFieldDefaultState extends State<CustomTextFieldDefault> {

  TextEditingController controller = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: controller,
      onChanged: widget.onChange,
      decoration: InputDecoration(
        filled: true,
        fillColor: const Color(0xff543D3D).withOpacity(0.15),
        isDense: true,
        border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide:
            const BorderSide(color: Colors.black, width: 1.0)),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15),
          borderSide: const BorderSide(
              color: Color(0xffDF9629), width: 1.0),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15),
          borderSide: const BorderSide(
              color: Color(0xffe5ac58), width: 1.0),
        ),
        hintText: widget.hintText,
        hintStyle: TextStyle(
          color: Colors.white.withOpacity(0.80),
          fontFamily: "KyivTypeSerif2",
        ),
      ),
      style: const TextStyle(
          fontFamily: "KyivTypeSerif2",
          fontSize: 15,
          color: Colors.black),
    );
  }
}
