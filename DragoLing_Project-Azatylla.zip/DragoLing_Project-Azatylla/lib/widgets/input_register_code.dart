import 'package:diplom_test/states/register_user_state.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../cubits/register_cubit.dart';
import 'custom_button_default.dart';
import 'custom_textfield_default.dart';

class InputRegisterCode extends StatefulWidget {
  const InputRegisterCode({super.key});

  @override
  State<InputRegisterCode> createState() => _InputRegisterCodeState();
}

class _InputRegisterCodeState extends State<InputRegisterCode> {
  @override
  Widget build(BuildContext context) {
    return BlocBuilder<RegisterCubit, RegisterUserState>(
      builder: (context, state) {
        return Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            CustomTextFieldDefault(
              hintText: "Код подтверждения",
              onChange: context.read<RegisterCubit>().enterCode,
            ),
            const SizedBox(height: 31),
            CustomButtonDefault(
              caption: "отправить".toUpperCase(),
              onTap: () {
                context.read<RegisterCubit>().confirm();
              },
            ),
          ],
        );
      },
    );
  }
}
