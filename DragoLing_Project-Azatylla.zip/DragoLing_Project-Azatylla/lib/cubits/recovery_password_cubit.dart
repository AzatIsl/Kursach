import 'dart:convert';

import 'package:diplom_test/managers/network_manager.dart';
import 'package:diplom_test/states/recovery_password_state.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class RecoveryPasswordCubit extends Cubit<RecoveryPasswordState> {
  RecoveryPasswordCubit() : super(RecoveryPasswordState());

  void next() {
    if (state.step == RecoveryPasswordStep.email) {
      String body = jsonEncode({"email": state.email});

      NetworkManager().sendPost("users/recovery_password", body).then((value) {
        if (value.statusCode == 200) {
          emit(state.copyWith(step: RecoveryPasswordStep.code));
        }
      });
    } else if (state.step == RecoveryPasswordStep.code) {
      String body = jsonEncode({
        "email": state.email,
        "code": state.code,
      });

      NetworkManager()
          .sendPost("users/recovery_password_confirm", body)
          .then((value) {
        if (value.statusCode == 200) {
          emit(state.copyWith(step: RecoveryPasswordStep.password));
        }
      });
    } else if (state.step == RecoveryPasswordStep.password) {
      String body = jsonEncode({
        "email": state.email,
        "code": state.code,
        "password": state.password,
      });

      NetworkManager()
          .sendPost("users/recovery_password_confirm", body)
          .then((value) {
        if (value.statusCode == 200) {
          emit(state.copyWith(step: RecoveryPasswordStep.success));
        }
      });
    }
  }

  void enterEmail(String text) {
    emit(state.copyWith(email: text));
  }

  void enterCode(String text) {
    emit(state.copyWith(code: text));
  }

  void enterPassword(String text) {
    emit(state.copyWith(password: text));
  }
}
