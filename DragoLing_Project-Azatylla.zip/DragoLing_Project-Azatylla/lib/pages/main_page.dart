import 'package:diplom_test/custom_page.dart';
import 'package:diplom_test/main.dart';
import 'package:diplom_test/pages/login_page/login_page.dart';
import 'package:diplom_test/pages/register_page/register_page.dart';

import 'package:diplom_test/widgets/custom_button_default.dart';
import 'package:flutter/material.dart';

class MainPage extends StatelessWidget {
  const MainPage({super.key});

  @override
  Widget build(BuildContext context) {
    return CustomPage(
      bottomCaption: "Знать много языков — значит иметь много ключей к одному замку.",
      child: Container(
        width: double.infinity,
        height: double.infinity,
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              CustomButtonDefault(
                caption: "ВОЙТИ В АККАУНТ",
                onTap: () {
                  Navigator.of(context).push(PageRouteBuilder(
                    transitionDuration: Duration.zero,
                    pageBuilder: (context, animation, secondaryAnimation) {
                      return LoginPage();
                    },
                  ));
                },
              ),
              CustomButtonDefault(
                caption: "СОЗДАТЬ АККАУНТ",
                onTap: () {
                  Navigator.of(context).push(PageRouteBuilder(
                    transitionDuration: Duration.zero,
                    pageBuilder: (context, animation, secondaryAnimation) {
                      return RegisterPage();
                    },
                  ));
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
