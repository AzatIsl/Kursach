import 'package:diplom_test/cubits/register_cubit.dart';
import 'package:diplom_test/custom_page.dart';
import 'package:diplom_test/pages/main_page.dart';
import 'package:diplom_test/widgets/back_button.dart';
import 'package:diplom_test/widgets/input_register_code.dart';
import 'package:diplom_test/widgets/register_fields.dart';
import 'package:diplom_test/widgets/slide_switcher.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../states/register_user_state.dart';

class RegisterPage extends StatefulWidget {
  const RegisterPage({super.key});

  @override
  State<RegisterPage> createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => RegisterCubit(),
      child: CustomPage(
        bottomCaption:
            'Китайский язык - это путь к пониманию самой большой нации и ее богатой истории.',
        child: Stack(
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 80, left: 10),
              child: CustomBackButton(onTap: () {
                Navigator.of(context).push(PageRouteBuilder(
                  pageBuilder: (context, animation, secondaryAnimation) {
                    return const MainPage();
                  },
                ));
              }),
            ),
            SizedBox(
                width: double.infinity,
                height: double.infinity,
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 30),
                  child: Center(
                    child: BlocBuilder<RegisterCubit, RegisterUserState>(
                      builder: (context, state) {
                        Widget widget;
                        if (state.step == RegisterUserStep.register) {
                          widget = const RegisterFields();
                        } else if (state.step == RegisterUserStep.confirm) {
                          widget = const InputRegisterCode();
                        } else {
                          WidgetsBinding.instance
                              .addPostFrameCallback((timeStamp) {
                            Navigator.of(context).push(PageRouteBuilder(
                              pageBuilder:
                                  (context, animation, secondaryAnimation) {
                                return const MainPage();
                              },
                            ));
                          });
                          widget = const Text('...');
                        }

                        return SlideSwitcher(
                            inAnimation: const SlideSwitcherAnimation(
                                begin: Offset(-2, 0),
                                curve: Curves.easeOut,
                                delay: Duration(milliseconds: 100),
                                duration: Duration(milliseconds: 250)),
                            outAnimation: const SlideSwitcherAnimation(
                                end: Offset(2, 0),
                                curve: Curves.easeIn,
                                duration: Duration(milliseconds: 100)),
                            child: widget);
                      },
                    ),
                  ),
                )),
          ],
        ),
      ),
    );
  }
}
