import 'package:diplom_test/cubits/login_cubit.dart';
import 'package:diplom_test/widgets/custom_textfield_default.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../custom_page.dart';
import '../../widgets/back_button.dart';
import '../../widgets/custom_button_default.dart';
import '../main_page.dart';
import '../recovery_password_page/recovery_password_page.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  @override
  Widget build(BuildContext context) {
    LoginCubit cubit = context.read<LoginCubit>();

    return CustomPage(
      bottomCaption:
          "Китайский язык - это путь к пониманию самой большой нации и ее богатой истории.",
      child: Stack(
        children: [
          Padding(
            padding: const EdgeInsets.only(top: 80, left: 10),
            child: CustomBackButton(onTap: () {
              Navigator.of(context).push(PageRouteBuilder(
                pageBuilder: (context, animation, secondaryAnimation) {
                  return const MainPage();
                },
              ));
            }),
          ),
          SizedBox(
            width: double.infinity,
            height: double.infinity,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 30),
              child: Center(
                  child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const SizedBox(height: 15),
                  CustomTextFieldDefault(
                    hintText: "Введите email",
                    onChange: cubit.enterEmail,
                  ),
                  const SizedBox(height: 15),
                  CustomTextFieldDefault(
                    hintText: "Введите пароль",
                    onChange: cubit.enterPassword,
                  ),
                  const SizedBox(height: 12),
                  GestureDetector(
                    onTap: () {
                      Navigator.of(context).push(PageRouteBuilder(
                        transitionDuration: Duration.zero,
                        pageBuilder: (context, animation, secondaryAnimation) {
                          return const RecoveryPasswordPage();
                        },
                      ));
                    },
                    child: Padding(
                      padding: const EdgeInsets.only(left: 10),
                      child: Container(
                        alignment: Alignment.centerLeft,
                        child: Text(
                          "Забыли пароль?",
                          style: TextStyle(
                              fontSize: 13,
                              fontFamily: "KyivTypeSerif2",
                              color: Colors.white.withOpacity(0.8)),
                        ),
                      ),
                    ),
                  ),
                  CustomButtonDefault(
                    caption: "ПРОДОЛЖИТЬ",
                    onTap: () {
                      cubit.login(context);
                    },
                  ),
                ],
              )),
            ),
          ),
        ],
      ),
    );
  }
}
