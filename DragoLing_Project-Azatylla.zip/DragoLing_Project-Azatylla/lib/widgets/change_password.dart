import 'package:diplom_test/widgets/custom_textfield_default.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../cubits/recovery_password_cubit.dart';

class ChangePassword extends StatefulWidget {
  const ChangePassword({super.key});

  @override
  State<ChangePassword> createState() => _ChangePasswordState();
}

class _ChangePasswordState extends State<ChangePassword> {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Align(
          alignment: Alignment.center,
          child: Text(
            "Введите ваш новый пароль",
            style: TextStyle(
                fontFamily: "KyivTypeSerif2",
                fontSize: 13,
                color: Colors.white.withOpacity(0.80)),
          ),
        ),
        const SizedBox(height: 9),
        CustomTextFieldDefault(
          hintText: "Введите новый пароль",
          onChange: (text) {
            context.read<RecoveryPasswordCubit>().enterPassword(text);
          },
        ),
      ],
    );
  }
}
