import 'package:diplom_test/cubits/recovery_password_cubit.dart';
import 'package:diplom_test/pages/login_page/login_page.dart';
import 'package:diplom_test/states/recovery_password_state.dart';
import 'package:diplom_test/widgets/change_password.dart';
import 'package:diplom_test/widgets/input_code.dart';
import 'package:diplom_test/widgets/input_email.dart';
import 'package:diplom_test/widgets/slide_switcher.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../custom_page.dart';
import '../../widgets/back_button.dart';
import '../../widgets/custom_button_default.dart';

import '../main_page.dart';

class RecoveryPasswordPage extends StatefulWidget {
  const RecoveryPasswordPage({super.key});

  @override
  State<RecoveryPasswordPage> createState() => _RecoveryPasswordPageState();
}

class _RecoveryPasswordPageState extends State<RecoveryPasswordPage> {
  @override
  Widget build(BuildContext context) {
    return CustomPage(
      bottomCaption:
          'Китайский язык - это путь к пониманию самой большой нации и ее богатой истории.',
      child: BlocProvider(
        create: (_) => RecoveryPasswordCubit(),
        child: Stack(
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 80, left: 10),
              child: CustomBackButton(onTap: () {
                Navigator.of(context).push(PageRouteBuilder(
                  pageBuilder: (context, animation, secondaryAnimation) {
                    return const LoginPage();
                  },
                ));
              }),
            ),
            Container(
              width: double.infinity,
              height: double.infinity,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 30),
                child: Center(
                  child:
                      BlocBuilder<RecoveryPasswordCubit, RecoveryPasswordState>(
                    builder: (context, state) {
                      Widget widget;
                      if (state.step == RecoveryPasswordStep.email) {
                        widget = const InputEmail();
                      } else if (state.step == RecoveryPasswordStep.code) {
                        widget = const InputCode();
                      } else if (state.step == RecoveryPasswordStep.password) {
                        widget = const ChangePassword();
                      } else {
                        widget = Text("д@сс2к@");
                      }

                      return Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          SlideSwitcher(
                              inAnimation: const SlideSwitcherAnimation(
                                begin: Offset(-2, 0),
                                duration: Duration(milliseconds: 250),
                                delay: Duration(milliseconds: 100),
                                curve: Curves.easeOut,
                              ),
                              outAnimation: const SlideSwitcherAnimation(
                                end: Offset(2, 0),
                                duration: Duration(milliseconds: 100),
                                curve: Curves.easeIn,
                              ),
                              child: widget),
                          const SizedBox(height: 12),
                          CustomButtonDefault(
                            caption: "ПРОДОЛЖИТЬ",
                            onTap: () {
                              if (state.step == RecoveryPasswordStep.success) {
                                Navigator.of(context).push(PageRouteBuilder(
                                  pageBuilder:
                                      (context, animation, secondaryAnimation) {
                                    return MainPage();
                                  },
                                ));
                                return;
                              }
                              context.read<RecoveryPasswordCubit>().next();
                            },
                          ),
                        ],
                      );
                    },
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
