import 'package:flutter/material.dart';

class CustomBackButton extends StatelessWidget {
  final Function? onTap;

  const CustomBackButton({super.key, this.onTap});

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.topLeft,
      child: GestureDetector(
        onTap: () {
          if (onTap != null) onTap!();
        },
        child: Image(
          image: const AssetImage('assets/icons/backicon.png'),
          color: Colors.black.withOpacity(0.40),
          width: 30,
          height: 30,
        ),
      ),
    );
  }
}
