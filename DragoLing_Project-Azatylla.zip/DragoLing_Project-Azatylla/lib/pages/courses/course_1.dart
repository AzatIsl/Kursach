import 'package:diplom_test/pages/course_page/course_page.dart';
import 'package:flutter/material.dart';

import '../../custom_page.dart';
import '../../widgets/back_button.dart';

class Course1 extends StatefulWidget {
  const Course1({super.key});

  @override
  State<Course1> createState() => _Course1State();
}

class _Course1State extends State<Course1> {
  @override
  Widget build(BuildContext context) {
    return CustomPage(
      bottomCaption:
          "Китайский язык - это путь к пониманию самой большой нации и ее богатой истории.",
      child: Stack(
        children: [
          Padding(
            padding: const EdgeInsets.only(top: 80, left: 10),
            child: CustomBackButton(
              onTap: () {
                Navigator.of(context).push(
                  PageRouteBuilder(
                    pageBuilder: (context, animation, secondaryAnimation) {
                      return const CoursePage();
                    },
                  ),
                );
              },
            ),
          ),
          SizedBox(
            width: double.infinity,
            height: double.infinity,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 50),
              child: Center(
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Image(
                        image: AssetImage('assets/images/hieroglyphs.png'),
                        width: 200,
                        height: 200,
                      ),
                      SizedBox(height: 10),
                      Text(
                        "Китайские символы — это письменность, которая используется в Китае уже несколько тысячелетий.",
                      ),
                      SizedBox(height: 10),
                      Text(
                        "Они состоят из более чем 50 тысяч иероглифов, каждый из которых имеет своё значение и историю!",
                      ),
                      SizedBox(height: 10),
                      Text(
                        "Как вообще устроены иероглифы? Китайские иероглифы можно поделить на две группы знаков – идеографические и фоноидеографические.",
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
