import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class CustomPage extends StatefulWidget {
  final String bottomCaption;
  final Widget child;

  const CustomPage({super.key, this.bottomCaption = "", required this.child});

  @override
  State<CustomPage> createState() => _CustomPageState();
}

class _CustomPageState extends State<CustomPage>
    with SingleTickerProviderStateMixin {
  late AnimationController controller;

  @override
  void initState() {
    super.initState();

    controller = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1500))
      ..forward();
  }

  @override
  void dispose() {
    super.dispose();
    controller.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Container(
            decoration: BoxDecoration(
                gradient: LinearGradient(
                    stops: [0.0, 0.45, 0.55, 1.0],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      Color(0xff01332D),
                      Color(0xff8E8350),
                      Color(0xff8E8350),
                      Color(0xff01332D),
                    ])),
          ),
          Opacity(
            opacity: 0.15,
            child: Container(
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: AssetImage("assets/images/bg4.png"),
                  fit: BoxFit.contain,
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 30, left: 10),
            child: Align(
              alignment: Alignment.topLeft,
              child: Text(
                "DragoLing",
                style: TextStyle(
                    fontFamily: "KyivTypeSerif2",
                    fontSize: 32,
                    color: Colors.black.withOpacity(0.30)),
              ),
            ),
          ),
          FadeTransition(
            opacity: Tween<double>(begin: 0, end: 1).animate(
                CurvedAnimation(parent: controller, curve: Curves.easeOut)),
            child: Padding(
              key: Key(widget.bottomCaption),
              padding: const EdgeInsets.only(bottom: 16),
              child: Align(
                alignment: Alignment.bottomCenter,
                child: Text(
                    textAlign: TextAlign.center,
                    widget.bottomCaption,
                    style: TextStyle(
                        fontSize: 15,
                        fontFamily: "KyivTypeSerif2",
                        color: Colors.black.withOpacity(0.5))),
              ),
            ),
          ),
          widget.child
        ],
      ),
    );
  }
}
