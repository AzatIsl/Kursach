class RecoveryPasswordState {
  var step = RecoveryPasswordStep.email;
  String email = "";
  String code = "";
  String password = "";

  RecoveryPasswordState({
    this.step = RecoveryPasswordStep.email,
    this.email = "",
    this.code = "",
    this.password = "",
  });

  RecoveryPasswordState copyWith({
    RecoveryPasswordStep? step,
    String? email,
    String? code,
    String? password,
  }) {
    return RecoveryPasswordState(
      step: step ?? this.step,
      email: email ?? this.email,
      code: code ?? this.code,
      password: password ?? this.password,
    );
  }
}

enum RecoveryPasswordStep {
  email,
  code,
  password,
  success
}