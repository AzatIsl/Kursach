import 'dart:convert';

import 'package:diplom_test/models/user.dart';
import 'package:diplom_test/states/register_user_state.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../managers/network_manager.dart';

class RegisterCubit extends Cubit<RegisterUserState> {
  RegisterCubit() : super(RegisterUserState(user: User()));

  RegisterUserStep step = RegisterUserStep.register;

  void enterName(String text) {
    state.user.name = text;
    emit(state.copyWith());
  }

  void enterEmail(String text) {
    state.user.email = text;
    emit(state.copyWith());
  }

  void enterPassword(String text) {
    state.user.password = text;
    emit(state.copyWith());
  }

  void enterCode(String text) {
    state.user.code = text;
    emit(state.copyWith());
  }

  void create() {
    final String body = jsonEncode(<String, String>{
      'name': state.user.name,
      'email': state.user.email,
      'password': state.user.password,
    });

    NetworkManager().sendPost("users/register", body).then((result) {
      if (result.statusCode == 200) {
        var json = jsonDecode(result.body);
        state.user.id = json['id'];
        emit(state.copyWith(step: RegisterUserStep.confirm));
      } else {
        var json = jsonDecode(result.body);

        emit(state.copyWith(step: RegisterUserStep.confirm));
      }
    });
  }

  void confirm() {
    final String body = jsonEncode(<String, String>{
      'id': state.user.id,
      'code': state.user.code,
    });

    NetworkManager().sendPost("users/confirm", body).then((result) {
      if (result.statusCode == 200) {
        emit(state.copyWith(step: RegisterUserStep.success));
      }
    });
  }
}
