import 'package:flutter/material.dart';

class CustomButtonDefault extends StatefulWidget {
  final String caption;
  final Function? onTap;
  final Function(BuildContext)? onTapWithContext;

  const CustomButtonDefault(
      {this.caption = "", this.onTap, super.key, this.onTapWithContext});

  @override
  State<CustomButtonDefault> createState() => _CustomButtonDefaultState();
}

class _CustomButtonDefaultState extends State<CustomButtonDefault> {
  double _opacity = 1.0;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (details) {
        _opacity = 0.5;
        setState(() {});
      },
      onTapUp: (details) {
        _opacity = 1.0;
        setState(() {});
      },
      onTap: () {
        if (widget.onTap != null) {
          widget.onTap!();
        }
        if (widget.onTapWithContext != null) widget.onTapWithContext!(context);
      },
      child: AnimatedOpacity(
        opacity: _opacity,
        duration: const Duration(microseconds: 250),
        child: Container(
          decoration: BoxDecoration(
            shape: BoxShape.rectangle,
            border: Border.all(
              color: const Color(0xffDF9629),
              width: 1.0,
            ),
            borderRadius: BorderRadius.circular(10),
            color: const Color(0xff543D3D).withOpacity(0.15),
          ),
          alignment: Alignment.center,
          width: 270,
          height: 50,
          margin: const EdgeInsets.all(10.0),
          child: Text(
            widget.caption,
            style: const TextStyle(color: Colors.white, fontFamily: "KyivTypeSerif"),
          ),
        ),
      ),
    );
  }
}
