import 'package:diplom_test/pages/courses/course_1.dart';
import 'package:flutter/material.dart';

import '../../custom_page.dart';
import '../../widgets/course_button.dart';

class CoursePage extends StatefulWidget {
  const CoursePage({super.key});

  @override
  State<CoursePage> createState() => _CoursePageState();
}

class _CoursePageState extends State<CoursePage> {
  @override
  Widget build(BuildContext context) {
    return CustomPage(
      child: Stack(
        children: [
          Padding(
            padding: const EdgeInsets.only(top: 80, left: 110),
            child: Align(
              alignment: Alignment.topLeft,
              child: Text(
                "Глава I. Символы",
                style: TextStyle(
                    fontFamily: "KyivTypeSerif2",
                    fontSize: 20,
                    color: Colors.black.withOpacity(0.40)),
              ),
            ),
          ),
          Container(
            width: double.infinity,
            height: double.infinity,
            child: Padding(
              padding: EdgeInsets.only(top: 120, left: 165),
              child: Row(
                children: [
                  Column(
                    children: [
                      CourseButton(
                          text: "1",
                          onTap: () {
                            Navigator.of(context).push(PageRouteBuilder(
                              pageBuilder:
                                  (context, animation, secondaryAnimation) {
                                return const Course1();
                              },
                            ));
                          }),
                    ],
                  ),
                ],
              ),
            ),
          ),
          Container(
            width: double.infinity,
            height: double.infinity,
            child: const Padding(
              padding: EdgeInsets.only(top: 210, left: 65),
              child: Row(
                children: [
                  Column(
                    children: [
                      CourseButton(text: "2"),
                    ],
                  ),
                  SizedBox(width: 123),
                  Column(
                    children: [
                      CourseButton(text: "3"),
                    ],
                  ),
                ],
              ),
            ),
          ),
          Container(
            width: double.infinity,
            height: double.infinity,
            child: const Padding(
              padding: EdgeInsets.only(top: 300, left: 165),
              child: Row(
                children: [
                  Column(
                    children: [
                      CourseButton(text: "4"),
                    ],
                  ),
                ],
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 400, left: 90),
            child: Align(
              alignment: Alignment.topLeft,
              child: Text(
                "Глава II. Грамматика",
                style: TextStyle(
                    fontFamily: "KyivTypeSerif2",
                    fontSize: 20,
                    color: Colors.black.withOpacity(0.40)),
              ),
            ),
          ),
          Container(
            width: double.infinity,
            height: double.infinity,
            child: const Padding(
              padding: EdgeInsets.only(top: 450, left: 165),
              child: Row(
                children: [
                  Column(
                    children: [
                      CourseButton(text: "1"),
                    ],
                  ),
                ],
              ),
            ),
          ),
          Container(
            width: double.infinity,
            height: double.infinity,
            child: const Padding(
              padding: EdgeInsets.only(top: 540, left: 65),
              child: Row(
                children: [
                  Column(
                    children: [
                      CourseButton(text: "2"),
                    ],
                  ),
                  SizedBox(width: 123),
                  Column(
                    children: [
                      CourseButton(text: "3"),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
