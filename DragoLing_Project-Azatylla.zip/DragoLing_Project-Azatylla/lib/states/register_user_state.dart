import '../models/user.dart';

class RegisterUserState {
  RegisterUserStep step;
  User user;
  String? error;

  RegisterUserState({
    this.step = RegisterUserStep.register,
    this.error = "",
    required this.user,
  });

  RegisterUserState copyWith({
    RegisterUserStep? step,
    User? user,
    String? error,
  }) {
    return RegisterUserState(
        step: step ?? this.step,
        user: user ?? this.user,
        error: error ?? this.error);
  }
}

enum RegisterUserStep { register, confirm, success, error, loading }
