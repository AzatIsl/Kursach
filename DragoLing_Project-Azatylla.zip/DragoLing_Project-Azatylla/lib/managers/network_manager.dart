import 'package:http/http.dart';

class NetworkManager {
  static final NetworkManager _instance = NetworkManager._internal();
  String host = "192.168.0.236:3000";

  factory NetworkManager() {
    return _instance;
  }

  NetworkManager._internal();

  Future<Response> sendPost(String resource, String body) {
    return post(
      Uri.parse('http://${host}/${resource}'),
      headers: <String, String>{
        'Content-Type': 'application/json; charset=UTF-8',
      },
      body: body,
    );
  }

  Future<Response> sendPostWithToken(
      String resource, String body, String token) {
    return post(
      Uri.parse('http://$host/$resource'),
      headers: <String, String>{
        'Content-Type': 'application/json; charset=UTF-8',
      },
      body: body,
    );
  }
}
