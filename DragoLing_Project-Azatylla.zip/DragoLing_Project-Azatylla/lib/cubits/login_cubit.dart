import 'dart:convert';

import 'package:diplom_test/models/user.dart';
import 'package:diplom_test/pages/course_page/course_page.dart';
import 'package:diplom_test/states/login_state.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../managers/network_manager.dart';

class LoginCubit extends Cubit<LoginState> {
  LoginCubit() : super(LoginState(user: User()));

  void enterEmail(String text) {
    state.user.email = text;
    emit(state.copyWith());
  }

  void enterPassword(String text) {
    state.user.password = text;
    emit(state.copyWith());
  }

  void _navigate(BuildContext context) {
    Navigator.of(context).push(PageRouteBuilder(
      pageBuilder: (context, animation, secondaryAnimation) {
        return const CoursePage();
      },
    ));
  }

  void login(BuildContext context) {
    final String body = jsonEncode(<String, String>{
      'email': state.user.email,
      'password': state.user.password,
    });

    NetworkManager().sendPost("login", body).then((result) {
      var json = jsonDecode(result.body);
      if (result.statusCode == 200) {
        state.token = json['token'];
        _navigate(context);
      } else {
        state.token = null;
        state.error = json['error'];
      }
      emit(state.copyWith());
    });
  }
}
