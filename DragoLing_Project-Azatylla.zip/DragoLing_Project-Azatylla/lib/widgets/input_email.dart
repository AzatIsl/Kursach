import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../cubits/recovery_password_cubit.dart';
import 'custom_textfield_default.dart';

class InputEmail extends StatefulWidget {
  const InputEmail({super.key});

  @override
  State<InputEmail> createState() => _InputEmailState();
}

class _InputEmailState extends State<InputEmail>
    with SingleTickerProviderStateMixin {

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Align(
          alignment: Alignment.center,
          child: Text(
            "Вам придет письмо с кодом подтверждения",
            style: TextStyle(
                fontFamily: "KyivTypeSerif2",
                fontSize: 13,
                color: Colors.white.withOpacity(0.80)),
          ),
        ),
        SizedBox(height: 9),
        CustomTextFieldDefault(
            hintText: "Введите email",
            onChange: (text) {
              context.read<RecoveryPasswordCubit>().enterEmail(text);
            }),
      ],
    );
  }
}
