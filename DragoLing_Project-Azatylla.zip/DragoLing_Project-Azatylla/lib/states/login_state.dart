import '../models/user.dart';

class LoginState {
  String? token;
  String? error;
  User user;

  LoginState({this.token, this.error, required this.user});

  LoginState copyWith({
    String? token,
    User? user,
    String? error,
  }) {
    return LoginState(
        token: token ?? this.token,
        user: user ?? this.user,
        error: error ?? this.error);
  }
}
