import 'package:flutter/cupertino.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../cubits/register_cubit.dart';
import '../states/register_user_state.dart';
import 'custom_button_default.dart';
import 'custom_textfield_default.dart';

class RegisterFields extends StatefulWidget {
  const RegisterFields({super.key});

  @override
  State<RegisterFields> createState() => _RegisterFieldsState();
}

class _RegisterFieldsState extends State<RegisterFields> {
  @override
  Widget build(BuildContext context) {
    return BlocBuilder<RegisterCubit, RegisterUserState>(
        builder: (context, state) {
      RegisterCubit cubit = context.read<RegisterCubit>();
      return Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const SizedBox(height: 15),
          CustomTextFieldDefault(
              hintText: "Введите имя", onChange: cubit.enterName),
          const SizedBox(height: 15),
          CustomTextFieldDefault(
            hintText: "Введите ваш email",
            onChange: cubit.enterEmail,
          ),
          const SizedBox(height: 12),
          CustomTextFieldDefault(
            hintText: "Введите пароль",
            onChange: cubit.enterPassword,
          ),
          const SizedBox(height: 31),
          CustomButtonDefault(
            caption: "СОЗДАТЬ",
            onTap: () {
              cubit.create();
            },
          ),
        ],
      );
    });
  }
}
