import 'package:flutter/cupertino.dart';


class SlideSwitcher extends StatefulWidget {
  final Widget? child;

  final SlideSwitcherAnimation inAnimation;
  final SlideSwitcherAnimation outAnimation;

  const SlideSwitcher({
    super.key,
    this.child,
    this.inAnimation = const SlideSwitcherAnimation(),
    this.outAnimation = const SlideSwitcherAnimation(),
  });

  @override
  State<SlideSwitcher> createState() => _SlideSwitcherState();
}

class _SlideSwitcherState extends State<SlideSwitcher>
    with TickerProviderStateMixin {
  Widget? _oldWidgget;
  late AnimationController enterController;
  late AnimationController exitController;
  late Animation<Offset> enterAnimation;
  late Animation<Offset> exitAnimation;

  @override
  void initState() {
    super.initState();

    enterController =
        AnimationController(vsync: this, duration: widget.inAnimation.duration);
    enterAnimation = Tween<Offset>(
            begin: widget.inAnimation.begin, end: widget.inAnimation.end)
        .animate(CurvedAnimation(
            parent: enterController, curve: widget.inAnimation.curve));

    exitController = AnimationController(
        vsync: this, duration: widget.outAnimation.duration);
    exitAnimation = Tween<Offset>(
            begin: widget.outAnimation.begin, end: widget.outAnimation.end)
        .animate(CurvedAnimation(
            parent: exitController, curve: widget.outAnimation.curve));

    enterController.forward();
  }


  @override
  void didUpdateWidget(covariant SlideSwitcher oldWidget) {
    super.didUpdateWidget(oldWidget);

    if (oldWidget.child == widget.child && oldWidget.child?.key == widget.child?.key) {
      return;
    }

    _oldWidgget = oldWidget.child;

    enterController.reset();
    exitController.reset();

    Future.delayed(widget.outAnimation.delay, () {
      if(mounted) {
        exitController.forward().whenComplete(() {
          _oldWidgget = null;
          setState(() {});
        });
      }
    });

    Future.delayed(widget.inAnimation.delay, () {
      if(mounted) {
        enterController.forward();
      }
    });
  }

  @override
  void dispose() {
    super.dispose();
    enterController.dispose();
    exitController.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(children: [
      if (_oldWidgget != null)
        SlideTransition(position: exitAnimation, child: _oldWidgget),
      if (widget.child != null)
        SlideTransition(position: enterAnimation, child: widget.child),
    ]);
  }
}

class SlideSwitcherAnimation {
  final Duration duration;
  final Duration delay;
  final Offset begin;
  final Offset end;
  final Curve curve;

  const SlideSwitcherAnimation(
      {this.begin = Offset.zero,
      this.end = Offset.zero,
      this.duration = Duration.zero,
      this.delay = Duration.zero,
      this.curve = Curves.linear});
}
