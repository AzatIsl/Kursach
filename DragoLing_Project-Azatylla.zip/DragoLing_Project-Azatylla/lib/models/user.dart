class User {
  String id;
  String name;
  String email;
  String code;
  String password;

  User(
      {this.id = "",
      this.name = "",
      this.email = "",
      this.code = "",
      this.password = ""});

  User copyWith(
      {String? id,
      String? name,
      String? email,
      String? code,
      String? password}) {
    return User(
      id: id ?? this.id,
      name: name ?? this.name,
      email: email ?? this.email,
      code: code ?? this.code,
      password: password ?? this.password,
    );
  }
}
